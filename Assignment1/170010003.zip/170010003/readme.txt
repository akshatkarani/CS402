Input: After running client, it will ask for input. Give input througt command line in specified format.
Output: After you give input, output will be displayed on command line.

Screenshot: output.png is screenshot of working of this program.
